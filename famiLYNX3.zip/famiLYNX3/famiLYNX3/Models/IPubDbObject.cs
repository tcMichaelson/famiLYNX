﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace famiLYNX3.Models {
    interface IPubDbObject {
        string Key { get; set; }
    }
}
