﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace famiLYNX3.Services {

    public class OrgRoleDTO {
        public FamilyTypeDTO OrgType { get; set; }
        public string RoleName { get; set; }
    }
}